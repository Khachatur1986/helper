squid-scripts
=============

this is some redirectors scripts of squid shared by g0tmi1k.
here is his blog:http://blog.g0tmi1k.com it is very funny.

so you can get a lot of fun using squid's redirectors.

u can connect me: linvex.k@gmail.com or http://weibo.com/linvex

just hava fun ;)

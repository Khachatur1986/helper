client.railgun.user32.MessageBoxA(0,"Corrupt file. Please re-download","Setup","MB_OK")

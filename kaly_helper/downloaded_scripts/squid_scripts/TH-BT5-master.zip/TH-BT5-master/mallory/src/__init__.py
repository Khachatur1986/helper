"""
Welcome to the Mallory developer documentation
"""
